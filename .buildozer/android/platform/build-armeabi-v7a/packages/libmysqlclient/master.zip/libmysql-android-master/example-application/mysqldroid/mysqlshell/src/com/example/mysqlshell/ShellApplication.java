package com.example.mysqlshell;

import android.app.Application;

public class ShellApplication extends Application {
	
	public ConnectionListItem current;
};

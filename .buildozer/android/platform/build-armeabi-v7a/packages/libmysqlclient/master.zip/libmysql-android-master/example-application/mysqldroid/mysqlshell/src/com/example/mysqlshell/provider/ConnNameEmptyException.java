package com.example.mysqlshell.provider;

import android.database.SQLException;

public class ConnNameEmptyException 
	extends SQLException { };


package com.example.mysqlshell;

public class QueryListItem {
    
    public String name;
    public String sql;

    public String toString() 
        { return name; }
    
};

package com.example.mysqlshell.tests;

public class OkConnection {

    public static String name = "Test ok connection example";

    public static String host = "192.168.103.23";

    public static String user = "rvs";

    public static String pass = "rvs";

    public static String db   = "rvs";

    public static String port = "8307";
}

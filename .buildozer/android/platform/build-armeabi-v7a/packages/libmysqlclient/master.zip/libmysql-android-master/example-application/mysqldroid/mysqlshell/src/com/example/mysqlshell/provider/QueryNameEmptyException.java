package com.example.mysqlshell.provider;

import android.database.SQLException;

public class QueryNameEmptyException 
	extends SQLException { };

